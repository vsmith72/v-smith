        <footer id="footer">
            <!--   TODO -- ADD SOCIAL MEDIA FOOTER -->
            <p>&lt;Designed and coded by Vanessa Smith 2016&gt;</p>
        </footer>
        </main><!-- end wrapper -->
        <script>
          //modal function
          $(document).ready(function(){
            $("#myBtn").click(function(){
              $("#myModal").modal();
            });
          });
          // 2nd modal
          $(document).ready(function(){
            $("#myBtn2").click(function(){
              $("#myModal2").modal();
            });
          });
        </script>
        <?php wp_footer(); ?>
    </body>
</html>
